function y = myfun(x)
y = sqrt(1 + sin(x)^2)
% 1./(x.^3-2*x-5); 

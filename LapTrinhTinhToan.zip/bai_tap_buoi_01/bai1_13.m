function bai1_13()
    x = [1 4 8];
    y = [2 1 5];
    A = [3 1 6; 5 2 7];
    x
    y
    A
    fprintf('1. x + y(hop le): ');
    disp(x+y);
    fprintf('2. x+A(khong hop le): \n');
    fprintf('3. x'' + y(khong hop le)\n');
    fprintf('4. A - [x'' y''](khong hop le)\n');
    fprintf('5. A - 3(hop le) \n');
    A-3;
end
syms x
g = exp(x)
ezplot(g)
% ezplot(g,[-2,2])

fprintf('1. Ket qua cua phep tinh 1 & -1 : \n   ');
disp(1 & -1);
fprintf('\n');

fprintf('2. Ket qua cua phep tinh 13 & (-6) : \n   ');
disp(13 & (-6));
fprintf('\n');

fprintf('3. Ket qua cua phep tinh 0 < -20 : \n   ');
disp(0 < -20);
fprintf('\n');

fprintf('4. Ket qua cua phep tinh 0 <= 0.2 <= 0.4 : \n   ');
disp(0 <= 0.2 <= 0.4);
fprintf('\n');

fprintf('1. Ket qua cua phep tinh 5 > 4 > 3 : \n   ');
disp(5 > 4 > 3);
fprintf('\n');

fprintf('1. Ket qua cua phep tinh 2 > 3 & 1 : \n   ');
disp(2 > 3 & 1);
fprintf('\n');

fprintf('Ket qua thu duoc nhu tren do matlab thuc hien tu trai sang phai cac phep so sanh va cac phep logic, va gia tri 0 duoc coi nhu False \n');
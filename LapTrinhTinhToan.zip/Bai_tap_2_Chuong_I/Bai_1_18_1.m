x = -pi : 0.1 : pi
y = x + sin(x)
plot(x, y)
title('Bai 1.18.2')
xlabel('Ox')
ylabel('Oy')
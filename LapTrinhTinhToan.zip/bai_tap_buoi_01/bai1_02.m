a = 36;
b = 15;

fprintf('1. mod(a, b) = '); disp(mod(a,b));
fprintf('\n');

fprintf('2. rem(a,b) = '); disp(rem(a,b));
fprintf('\n');

fprintf('3. gcd(a,b) = '); disp(gcd(a,b));
fprintf('\n');

fprintf('4. lcm(a,b) = '); disp(lcm(a,b));
fprintf('\n');

x = linspace(0, 2*pi)
y1 = sin(x)
y2 = sin(x + pi/2)
y3 = sin(x + pi/3) 
hold on
plot(x, y1)
plot(x, y2)
plot(x, y3)
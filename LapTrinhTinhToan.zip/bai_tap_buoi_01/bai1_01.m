
fprintf('1. Ket qua cua bieu thuc 10/2\\5 - 3 + 2*4 : \n   ');
disp(10/2\5 - 3 + 2*4);
fprintf('\n');

fprintf('2. Ket qua cua bieu thuc 3^2/4 : \n   ');
disp(3^2/4);
fprintf('\n');

fprintf('3. Ket qua cua bieu thuc 3^2^2 : \n   ');
disp(3^2^2);
fprintf('\n');

fprintf('4. Ket qua cua bieu thuc 2+round(6/9 + 3*2)/2�3 : \n   ');
disp(2+round(6/9 + 3*2)/2-3);
fprintf('\n');

fprintf('5. Ket qua cua bieu thuc 2+floor(6/11)/2�3 : \n   ');
disp(2+floor(6/11)/2-3);
fprintf('\n');

fprintf('6. Ket qua cua bieu thuc 2+ceil(-6/9)�3 : \n   ');
disp(10/2\5 - 3 + 2*4);
fprintf('\n');

fprintf('1. Ket qua cua bieu thuc fix(-4/9)+fix(3*(5/6)) : \n   ');
disp(fix(-4/9)+fix(3*(5/6)));
fprintf('\n');


syms x y
ezmesh(sin(x)*cos(y),[0,10,0,10])
% ezmesh(x^2 - y^2, [-2, 2], [-2, 2])
% ezmesh(sin(x^5)*cos(y))
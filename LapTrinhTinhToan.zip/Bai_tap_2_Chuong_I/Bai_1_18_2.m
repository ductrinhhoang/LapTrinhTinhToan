x = -pi : 0.1 : pi
y = x.^2
plot(x, y)
title('Bai 1.18.2')
xlabel('Ox')
ylabel('Oy')
function bai_2_4
syms x
fprintf('1) int(sqrt(1 + sin(x)^2), 0, pi) = ')
int(sqrt(1 + sin(x)^2), 0, pi)
fprintf('2) int(sqrt(1 + (sin(x))^4), 0, pi) = ')
int(sqrt(1 + sin(x)^4), 0, pi)

quadl(@myfun, 0, 2)
end